# Blog-Website

## for index.html , style.css and main.js follow up with the video
